using System;
using System.Collections.Generic;
using System.Linq;

namespace ChamCongTinhLuong;

public static class SalaryCalculator
{
    public static SalaryResult Calculate(Employee employee, IEnumerable<AttendanceRecord> source, int year, int month, bool includeAttendanceBonus, AppSettings? settings = null)
    {
        settings ??= new AppSettings();
        decimal standardDays = settings.StandardDays > 0 ? settings.StandardDays : 26m;
        decimal salaryBase = employee.SalaryBase > 0 ? employee.SalaryBase : 8_500_000m;
        decimal otBase = employee.OvertimeBase > 0 ? employee.OvertimeBase : 7_000_000m;
        decimal dailyRate = salaryBase / standardDays;
        decimal hourlyOtRate = otBase / standardDays / 8m;
        var rows = source.Where(x => x.Date.Year == year && x.Date.Month == month).ToList();
        int daysInMonth = DateTime.DaysInMonth(year, month);
        int sundays = Enumerable.Range(1, daysInMonth).Count(d => new DateTime(year, month, d).DayOfWeek == DayOfWeek.Sunday);

        var result = new SalaryResult { CalendarWorkDays = daysInMonth - sundays };

        foreach (var r in rows)
        {
            bool sunday = r.Date.DayOfWeek == DayOfWeek.Sunday;

            if (r.Type == AttendanceType.PaidLeave && !sunday)
            {
                decimal units = r.PaidDayUnits > 0m ? r.PaidDayUnits : 1m;
                result.LeaveDays += units;
                result.PaidDays += units;
                continue;
            }

            if (r.Type == AttendanceType.Holiday && !sunday)
            {
                decimal units = r.PaidDayUnits > 0m ? r.PaidDayUnits : 1m;
                result.PaidDays += units;
                continue;
            }

            if (r.Type == AttendanceType.Work)
            {
                if (!sunday)
                {
                    result.WorkedDays += 1m;
                    result.PaidDays += 1m;

                    if (r.Shift == ShiftType.Night)
                        result.NightExtraPay += hourlyOtRate * settings.NightExtraHours * settings.NightExtraRate;

                    if (r.OvertimeHours > 0)
                    {
                        if (r.Shift == ShiftType.Night)
                            result.NightOtPay += NightOvertimePay(hourlyOtRate, r.OvertimeHours, settings);
                        else
                            result.DayOtPay += hourlyOtRate * r.OvertimeHours * settings.NormalOvertimeRate;
                    }
                }
                else
                {
                    decimal h = r.OvertimeHours > 0 ? r.OvertimeHours : settings.SundayDefaultHours;
                    if (r.Shift == ShiftType.Night)
                        result.SundayNightPay += hourlyOtRate * h * settings.SundayNightRate;
                    else
                        result.SundayDayPay += hourlyOtRate * h * settings.SundayDayRate;
                }
            }
            else if (r.Type == AttendanceType.OvertimeOnly)
            {
                if (sunday)
                    if (r.Shift == ShiftType.Night)
                        result.SundayNightPay += hourlyOtRate * r.OvertimeHours * settings.SundayNightRate;
                    else
                        result.SundayDayPay += hourlyOtRate * r.OvertimeHours * settings.SundayDayRate;
                else if (r.Shift == ShiftType.Night)
                    result.NightOtPay += NightOvertimePay(hourlyOtRate, r.OvertimeHours, settings);
                else
                    result.DayOtPay += hourlyOtRate * r.OvertimeHours * settings.NormalOvertimeRate;
            }
        }

        result.BasePay = dailyRate * result.PaidDays;
        result.AttendanceBonus = includeAttendanceBonus ? settings.AttendanceBonus : 0m;
        result.Insurance = salaryBase * settings.InsuranceRate;
        result.UnionFee = salaryBase * settings.UnionRate;
        result.Gross = result.BasePay + result.DayOtPay + result.NightOtPay + result.NightExtraPay + result.SundayPay + result.AttendanceBonus;
        result.Net = result.Gross - result.Insurance - result.UnionFee;
        return result;
    }

    private static decimal NightOvertimePay(decimal hourlyRate, decimal hours, AppSettings settings)
    {
        if (hours <= 0m) return 0m;
        decimal firstTwoHours = Math.Min(hours, 2m);
        decimal afterTwoHours = Math.Max(hours - 2m, 0m);
        return hourlyRate * (firstTwoHours * settings.NormalOvertimeRate + afterTwoHours * settings.NightOvertimeAfter2Rate);
    }
}
