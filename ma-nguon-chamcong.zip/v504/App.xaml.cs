using System.Windows;
namespace ChamCongTinhLuong;
public partial class App : Application { }
