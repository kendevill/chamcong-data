using System.Globalization;
using System.IO;
using Microsoft.Win32;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Threading;

namespace ChamCongTinhLuong;

public partial class MainWindow : Window
{
    readonly DataStore store = new(); AppData data; Employee current;
    DateTime selectedDate = DateTime.Today; readonly CultureInfo vi = new("vi-VN"); readonly DispatcherTimer timer = new(){Interval=TimeSpan.FromSeconds(1)};
    int Month => MonthCombo.SelectedItem is int m ? m : DateTime.Today.Month;
    int Year => YearCombo.SelectedItem is int y ? y : DateTime.Today.Year;
    ShiftType Shift => NightShift.IsChecked == true ? ShiftType.Night : ShiftType.Day;

    public MainWindow()
    {
        InitializeComponent();

        // Hiện cửa sổ ngay; dữ liệu GitHub tải nền sau khi UI đã xuất hiện.
        data=new AppData();
        if(data.Employees.Count==0) data.Employees.Add(new Employee{Name="Đang tải dữ liệu..."});
        current=data.Employees.First();

        LoadSelectors();
        timer.Tick+=(_,__)=>ClockText.Text=DateTime.Now.ToString("HH:mm:ss");
        timer.Start();
        RefreshAll();
        StatusText.Text="Đang tải dữ liệu từ GitHub...";

        Loaded+=MainWindow_Loaded;
    }

    async void MainWindow_Loaded(object sender,RoutedEventArgs e)
    {
        Loaded-=MainWindow_Loaded;
        try
        {
            data=await store.LoadAsync();
            current=data.Employees.First();

            if(ApplyMonthlyLeaveAccrual(DateTime.Today))
            {
                try { store.Save(data); }
                catch(Exception ex)
                {
                    MessageBox.Show("Đã tải dữ liệu nhưng chưa đồng bộ được phép tháng lên GitHub.\n\n"+ex.Message,
                        "GitHub",MessageBoxButton.OK,MessageBoxImage.Warning);
                }
            }

            RefreshAll();
        }
        catch(Exception ex)
        {
            StatusText.Text="Không tải được dữ liệu GitHub";
            MessageBox.Show(ex.Message,"GitHub",MessageBoxButton.OK,MessageBoxImage.Error);
        }
    }

    void LoadSelectors(){ for(int i=1;i<=12;i++)MonthCombo.Items.Add(i); for(int y=DateTime.Today.Year-4;y<=DateTime.Today.Year+4;y++)YearCombo.Items.Add(y); MonthCombo.SelectedItem=DateTime.Today.Month; YearCombo.SelectedItem=DateTime.Today.Year; }
    void RefreshAll(){ BonusCheck.Content=$"Chuyên cần +{Money(data.Settings.AttendanceBonus)}"; RefreshHeader(); RefreshCalendar(); RefreshDetail(); RefreshSalary(); RefreshStatus(); }
    void RefreshHeader(){
        EmployeeName.Text=current.Name;
        MainInitials.Text=Initials(current.Name);
        var monthRows=data.Attendance.Where(x=>x.EmployeeId==current.Id&&x.Date.Year==Year&&x.Date.Month==Month).ToList();
        var salary=SalaryCalculator.Calculate(current,monthRows,Year,Month,BonusCheck.IsChecked==true,data.Settings);
        var totalSalary=current.SalaryBase+data.Settings.AttendanceBonus;
        EmployeeMeta.Text=$"Mã NV: {current.Code}\nPhép còn: {current.AnnualLeaveBalance:0.#} ngày";
        EmployeeSalary.Text=$"Lương tổng: {Money(totalSalary)}\nLương tính tăng ca: {Money(current.OvertimeBase)}";
        EmployeeCards.Items.Clear();
        for(int i=0;i<5;i++){
            if(i<data.Employees.Count){var e=data.Employees[i]; var b=CardButton($"{e.Code}\n●\n{e.Name}", e.Id==current.Id); b.Tag=e; b.Click+=(s,_)=>{current=(Employee)((Button)s).Tag;RefreshAll();};EmployeeCards.Items.Add(b);}
            else { var b=CardButton("＋",false); b.ToolTip="Thêm nhân viên"; b.Click+=(_,__)=>AddEmployeeFromHeader(); EmployeeCards.Items.Add(b); }
        }
    }
    void AddEmployeeFromHeader(){ if(data.Employees.Count>=5){MessageBox.Show("App giới hạn tối đa 5 người.");return;} var emp=new Employee{Code=$"NV{data.Employees.Count+1:00}",LastLeaveAccrualDate=DateTime.Today}; if(EditEmployee(emp,true)){data.Employees.Add(emp);current=emp;store.Save(data);RefreshAll();} }
    Button CardButton(string text,bool selected){return new Button{Content=text,Margin=new Thickness(4,0,4,0),Background=selected?new SolidColorBrush(Color.FromRgb(245,248,255)):Brushes.White,BorderBrush=new SolidColorBrush(selected?Color.FromRgb(47,118,241):Color.FromRgb(226,231,239)),BorderThickness=new Thickness(selected?2:1),FontSize=12,Padding=new Thickness(6),HorizontalContentAlignment=HorizontalAlignment.Center,VerticalContentAlignment=VerticalAlignment.Center};}
    void RefreshCalendar()
    {
        CalendarTitle.Text=$"Lịch tháng {Month:00}/{Year}";
        MonthTitle.Text=$"Tổng kết tháng {Month:00}/{Year}";
        CalendarDays.Children.Clear();
        var first=new DateTime(Year,Month,1);
        int start=((int)first.DayOfWeek+6)%7;
        int days=DateTime.DaysInMonth(Year,Month);
        int prev=DateTime.DaysInMonth(first.AddMonths(-1).Year,first.AddMonths(-1).Month);

        for(int cell=0;cell<42;cell++)
        {
            int d=cell-start+1;
            bool cur=d>=1&&d<=days;
            DateTime date;
            string text;
            if(d<1){var pm=first.AddMonths(-1);int dd=prev+d;date=new DateTime(pm.Year,pm.Month,dd);text=dd.ToString();}
            else if(d>days){var nm=first.AddMonths(1);int dd=d-days;date=new DateTime(nm.Year,nm.Month,dd);text=dd.ToString();}
            else {date=new DateTime(Year,Month,d);text=d.ToString();}

            var fg = cur ? Brushes.Black : new SolidColorBrush(Color.FromRgb(184,190,201));
            var bg = Brushes.Transparent;
            var weight = FontWeights.SemiBold;

            if(cur)
            {
                var rows=data.Attendance.Where(x=>x.EmployeeId==current.Id&&x.Date.Date==date).ToList();
                if(selectedDate.Date==date)
                {
                    bg=new SolidColorBrush(Color.FromRgb(47,118,241));
                    fg=Brushes.White;
                    weight=FontWeights.Bold;
                }
                else if(date.DayOfWeek==DayOfWeek.Sunday)
                    fg=new SolidColorBrush(Color.FromRgb(239,68,68));
                else if(rows.Any(x=>x.Type==AttendanceType.PaidLeave))
                    fg=new SolidColorBrush(Color.FromRgb(239,68,68));
                else if(rows.Any(x=>x.Type==AttendanceType.OvertimeOnly||x.OvertimeHours>0))
                    fg=new SolidColorBrush(Color.FromRgb(255,138,31));
                else if(rows.Any(x=>x.Type is AttendanceType.Work or AttendanceType.Holiday))
                    fg=new SolidColorBrush(Color.FromRgb(33,155,85));
            }

            var b=new Button
            {
                Content=text,
                Width=38,
                Height=28,
                Margin=new Thickness(3,2,3,2),
                Padding=new Thickness(0),
                BorderThickness=new Thickness(0),
                Background=bg,
                Foreground=fg,
                FontWeight=weight,
                FontSize=13,
                HorizontalAlignment=HorizontalAlignment.Center,
                VerticalAlignment=VerticalAlignment.Center,
                HorizontalContentAlignment=HorizontalAlignment.Center,
                VerticalContentAlignment=VerticalAlignment.Center,
                Cursor=cur?System.Windows.Input.Cursors.Hand:System.Windows.Input.Cursors.Arrow
            };
            b.Template=RoundButtonTemplate();

            if(cur)
            {
                var capture=date;
                b.Click+=(_,__)=>{selectedDate=capture;RefreshCalendar();RefreshDetail();RefreshStatus();};
            }
            else b.IsHitTestVisible=false;
            CalendarDays.Children.Add(b);
        }
    }

    static ControlTemplate RoundButtonTemplate()
    {
        var border=new FrameworkElementFactory(typeof(Border));
        border.SetValue(Border.CornerRadiusProperty,new CornerRadius(15));
        border.SetBinding(Border.BackgroundProperty,new System.Windows.Data.Binding("Background"){RelativeSource=new System.Windows.Data.RelativeSource(System.Windows.Data.RelativeSourceMode.TemplatedParent)});
        var presenter=new FrameworkElementFactory(typeof(ContentPresenter));
        presenter.SetValue(ContentPresenter.HorizontalAlignmentProperty,HorizontalAlignment.Center);
        presenter.SetValue(ContentPresenter.VerticalAlignmentProperty,VerticalAlignment.Center);
        presenter.SetBinding(ContentPresenter.ContentProperty,new System.Windows.Data.Binding("Content"){RelativeSource=new System.Windows.Data.RelativeSource(System.Windows.Data.RelativeSourceMode.TemplatedParent)});
        border.AppendChild(presenter);
        return new ControlTemplate(typeof(Button)){VisualTree=border};
    }
    void RefreshDetail(){DetailDate.Text=selectedDate.ToString("dd/MM/yyyy")+(selectedDate.DayOfWeek==DayOfWeek.Sunday?"  •  Chủ nhật":"");var rows=data.Attendance.Where(x=>x.EmployeeId==current.Id&&x.Date.Date==selectedDate.Date).OrderBy(x=>x.Type).ToList();DayDetail.Text=rows.Count==0?"Chưa có chấm công.\n\nChọn ngày trên lịch để xem chi tiết.":string.Join("\n\n",rows.Select(r=>$"● {TypeName(r.Type)}  •  {(r.Shift==ShiftType.Day?"Ca ngày":"Ca đêm")}\n    Công: {PaidUnits(r):0.#}     OT: {r.OvertimeHours:0.#} giờ"));}
    decimal PaidUnits(AttendanceRecord r)=>r.Date.DayOfWeek!=DayOfWeek.Sunday&&(r.Type is AttendanceType.Work or AttendanceType.PaidLeave or AttendanceType.Holiday)?(r.Type==AttendanceType.PaidLeave?(r.PaidDayUnits>0?r.PaidDayUnits:1):1):0;
    void RefreshStatus(){SelectedDateText.Text=selectedDate.ToString("dddd, dd/MM/yyyy",vi);ClockText.Text=DateTime.Now.ToString("HH:mm:ss");var rows=data.Attendance.Where(x=>x.EmployeeId==current.Id&&x.Date.Date==selectedDate.Date).ToList();StatusText.Text=rows.Any(x=>x.Type==AttendanceType.Work)?"Trạng thái: Đã chấm đi làm":rows.Any(x=>x.Type==AttendanceType.PaidLeave)?"Trạng thái: Nghỉ phép":rows.Any(x=>x.Type==AttendanceType.Holiday)?"Trạng thái: Nghỉ lễ":rows.Any(x=>x.Type==AttendanceType.OvertimeOnly)?"Trạng thái: Đã chấm tăng ca":"Trạng thái: Chưa chấm công";}
    void RefreshSalary(){var rows=data.Attendance.Where(x=>x.EmployeeId==current.Id&&x.Date.Year==Year&&x.Date.Month==Month).OrderByDescending(x=>x.Date).ThenByDescending(x=>x.Id).ToList();AttendanceGrid.ItemsSource=rows.Select(r=>new{Date=r.Date.ToString("dd/MM/yyyy"),Type=TypeName(r.Type),Shift=r.Shift==ShiftType.Day?"Ngày":"Đêm",Paid=PaidUnits(r).ToString("0.#"),Ot=r.OvertimeHours.ToString("0.#"),Note=r.Date.DayOfWeek==DayOfWeek.Sunday?"Chủ nhật":r.Note}).ToList();var s=SalaryCalculator.Calculate(current,rows,Year,Month,BonusCheck.IsChecked==true,data.Settings);WorkDays.Text=$"{s.PaidDays:0.#} / {s.CalendarWorkDays}";BasePay.Text=Money(s.BasePay);OtPay.Text=Money(s.DayOtPay+s.NightOtPay);NightPay.Text=Money(s.NightExtraPay);SundayPay.Text=Money(s.SundayPay);BonusPay.Text=Money(s.AttendanceBonus);Insurance.Text="− "+Money(s.Insurance);Union.Text="− "+Money(s.UnionFee);NetPay.Text=Money(s.Net);GrossBreakdown.Text = string.Join("\n", new[] {
            $"{"Lương công",-24}{Money(s.BasePay),14}",
            $"{"OT",-24}{Money(s.DayOtPay+s.NightOtPay),14}",
            $"{$"Phụ cấp đêm {data.Settings.NightExtraRate*100m:0.##}%",-24}{Money(s.NightExtraPay),14}",
            $"{"Chủ nhật ngày",-24}{Money(s.SundayDayPay),14}",
            $"{"Chủ nhật đêm",-24}{Money(s.SundayNightPay),14}",
            $"{"Chuyên cần",-24}{Money(s.AttendanceBonus),14}",
            "────────────────────────────────────",
            $"{"Tổng trước khấu trừ",-24}{Money(s.Gross),14}",
            $"{$"Bảo hiểm {data.Settings.InsuranceRate*100m:0.##}%",-24}{("− "+Money(s.Insurance)),14}",
            $"{$"Công đoàn {data.Settings.UnionRate*100m:0.##}%",-24}{("− "+Money(s.UnionFee)),14}",
            "────────────────────────────────────",
            $"{"Thực nhận",-24}{Money(s.Net),14}"
        });}
    static string TypeName(AttendanceType t)=>t==AttendanceType.Work?"Đi làm":t==AttendanceType.PaidLeave?"Nghỉ phép":t==AttendanceType.Holiday?"Nghỉ lễ":"Tăng ca";
    bool HasMain(DateTime d)=>data.Attendance.Any(x=>x.EmployeeId==current.Id&&x.Date.Date==d&&(x.Type is AttendanceType.Work or AttendanceType.PaidLeave or AttendanceType.Holiday));
    void Save(){store.Save(data);RefreshAll();}
    void Work_Click(object s,RoutedEventArgs e){var d=selectedDate.Date;if(HasMain(d)){MessageBox.Show("Ngày này đã có dữ liệu công/nghỉ.");return;}decimal h=0;if(d.DayOfWeek==DayOfWeek.Sunday){var q=HoursDialog("Chủ nhật không tính công. Nhập số giờ làm:",data.Settings.SundayDefaultHours);if(q is null)return;h=q.Value;}data.Attendance.Add(new(){EmployeeId=current.Id,Date=d,Type=AttendanceType.Work,Shift=Shift,OvertimeHours=h});Save();}
    void Leave_Click(object s,RoutedEventArgs e){var d=selectedDate.Date;if(d.DayOfWeek==DayOfWeek.Sunday){MessageBox.Show("Chủ nhật không cần chấm nghỉ phép.");return;}if(HasMain(d)){MessageBox.Show("Ngày này đã có dữ liệu công/nghỉ.");return;}var u=LeaveDialog();if(u is null)return;if(current.AnnualLeaveBalance<u){MessageBox.Show($"Không đủ phép năm. Hiện còn {current.AnnualLeaveBalance:0.#} ngày.");return;}current.AnnualLeaveBalance-=u.Value;data.Attendance.Add(new(){EmployeeId=current.Id,Date=d,Type=AttendanceType.PaidLeave,Shift=Shift,PaidDayUnits=u.Value,Note=$"Nghỉ phép {u.Value:0.#} ngày"});Save();}
    void Holiday_Click(object s,RoutedEventArgs e){var d=selectedDate.Date;if(d.DayOfWeek==DayOfWeek.Sunday){MessageBox.Show("Chủ nhật không tính công.");return;}if(HasMain(d)){MessageBox.Show("Ngày này đã có dữ liệu công/nghỉ.");return;}data.Attendance.Add(new(){EmployeeId=current.Id,Date=d,Type=AttendanceType.Holiday,Shift=Shift,PaidDayUnits=1,Note="Nghỉ lễ - không trừ phép"});Save();}
    void Overtime_Click(object s,RoutedEventArgs e){var h=HoursDialog("Chọn số giờ tăng ca",3);if(h is null)return;data.Attendance.Add(new(){EmployeeId=current.Id,Date=selectedDate.Date,Type=AttendanceType.OvertimeOnly,Shift=Shift,OvertimeHours=h.Value});Save();}
    decimal? LeaveDialog(){var w=DialogWindow("Chọn nghỉ phép",360,180);decimal? result=null;var sp=new StackPanel{Margin=new Thickness(22)};sp.Children.Add(new TextBlock{Text="Nghỉ phép bao nhiêu ngày?",FontSize=17,FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,0,0,16)});var g=new Grid();g.ColumnDefinitions.Add(new());g.ColumnDefinitions.Add(new());var a=new Button{Content="0,5 ngày",Margin=new Thickness(0,0,5,0)};var b=new Button{Content="1 ngày",Margin=new Thickness(5,0,0,0),Background=new SolidColorBrush(Color.FromRgb(47,118,241)),Foreground=Brushes.White};Grid.SetColumn(b,1);a.Click+=(_,__)=>{result=.5m;w.Close();};b.Click+=(_,__)=>{result=1m;w.Close();};g.Children.Add(a);g.Children.Add(b);sp.Children.Add(g);w.Content=sp;w.ShowDialog();return result;}
    decimal? HoursDialog(string title,decimal def){var w=DialogWindow("Tăng ca",390,250);decimal? result=null;var sp=new StackPanel{Margin=new Thickness(22)};sp.Children.Add(new TextBlock{Text=title,FontSize=17,FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,0,0,14)});var quick=new UniformGrid{Columns=3,Margin=new Thickness(0,0,0,14)};foreach(var v in new[]{1m,2m,3m}){var b=new Button{Content=$"{v:0} giờ",Margin=new Thickness(3)};b.Click+=(_,__)=>{result=v;w.Close();};quick.Children.Add(b);}sp.Children.Add(quick);var tb=new TextBox{Text=def.ToString("0.#"),Height=32};sp.Children.Add(tb);var ok=new Button{Content="Tùy chỉnh",Margin=new Thickness(0,10,0,0),Background=new SolidColorBrush(Color.FromRgb(255,126,19)),Foreground=Brushes.White};ok.Click+=(_,__)=>{if(decimal.TryParse(tb.Text.Replace(',', '.'),NumberStyles.Any,CultureInfo.InvariantCulture,out var v)&&v>0){result=v;w.Close();}};sp.Children.Add(ok);w.Content=sp;w.ShowDialog();return result;}
    Window DialogWindow(string title,double width,double height)=>new(){Title=title,Width=width,Height=height,WindowStartupLocation=WindowStartupLocation.CenterOwner,Owner=this,ResizeMode=ResizeMode.NoResize,Background=Brushes.White};
    void Delete_Click(object s,RoutedEventArgs e){var rows=data.Attendance.Where(x=>x.EmployeeId==current.Id&&x.Date.Date==selectedDate.Date).ToList();if(rows.Count==0){MessageBox.Show("Ngày này chưa có dữ liệu.");return;}if(rows.Count>1){MessageBox.Show("Ngày này có nhiều dòng. App sẽ xóa dòng được chọn trong bảng Tổng kết nếu cùng ngày; nếu chưa chọn thì xóa dòng cuối cùng.");}var rec=rows.Last();if(AttendanceGrid.SelectedItem!=null){var idx=AttendanceGrid.SelectedIndex;if(idx>=0){var monthRows=data.Attendance.Where(x=>x.EmployeeId==current.Id&&x.Date.Year==Year&&x.Date.Month==Month).OrderByDescending(x=>x.Date).ThenByDescending(x=>x.Id).ToList();if(idx<monthRows.Count&&monthRows[idx].Date.Date==selectedDate.Date)rec=monthRows[idx];}}if(MessageBox.Show($"Xóa {TypeName(rec.Type)} ngày {selectedDate:dd/MM/yyyy}?","Xác nhận",MessageBoxButton.YesNo)==MessageBoxResult.Yes){if(rec.Type==AttendanceType.PaidLeave)current.AnnualLeaveBalance+=rec.PaidDayUnits>0?rec.PaidDayUnits:1;data.Attendance.Remove(rec);Save();}}
    void PrevMonth_Click(object s,RoutedEventArgs e)=>MoveMonth(-1); void NextMonth_Click(object s,RoutedEventArgs e)=>MoveMonth(1); void Today_Click(object s,RoutedEventArgs e){selectedDate=DateTime.Today;MonthCombo.SelectedItem=selectedDate.Month;YearCombo.SelectedItem=selectedDate.Year;RefreshAll();}
    void MoveMonth(int step){var d=new DateTime(Year,Month,1).AddMonths(step);if(!YearCombo.Items.Contains(d.Year))YearCombo.Items.Add(d.Year);YearCombo.SelectedItem=d.Year;MonthCombo.SelectedItem=d.Month;selectedDate=new DateTime(d.Year,d.Month,1);RefreshAll();}
    void MonthYear_Changed(object s,SelectionChangedEventArgs e){if(MonthCombo.SelectedItem==null||YearCombo.SelectedItem==null)return;if(selectedDate.Year!=Year||selectedDate.Month!=Month)selectedDate=new DateTime(Year,Month,1);RefreshAll();}
    void Bonus_Changed(object s,RoutedEventArgs e){if(IsLoaded)RefreshSalary();}
    void ExportExcel_Click(object s, RoutedEventArgs e)
    {
        var dlg = new SaveFileDialog
        {
            Title = "Xuất bảng lương Excel",
            Filter = "Excel Workbook (*.xlsx)|*.xlsx",
            FileName = $"BangLuong_Thang_{Month:00}{Year}.xlsx",
            AddExtension = true,
            DefaultExt = ".xlsx"
        };
        if (dlg.ShowDialog() != true) return;
        try
        {
            ExcelExporter.Export(dlg.FileName, data, Year, Month, BonusCheck.IsChecked == true);
            MessageBox.Show($"Đã xuất Excel tháng {Month:00}/{Year}.\n\n{dlg.FileName}", "Xuất Excel", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show("Không thể xuất Excel:\n" + ex.Message, "Xuất Excel", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
    void Payroll_Click(object? s, RoutedEventArgs e)
    {
        int payrollMonth = Month;
        int payrollYear = Year;

        var w = DialogWindow($"Bảng lương  •  Tháng {payrollMonth:00}/{payrollYear}", 1380, 760);
        w.ResizeMode = ResizeMode.CanResize;
        w.WindowState = WindowState.Maximized;
        w.MinWidth = 1180;
        w.MinHeight = 650;

        var root = new DockPanel { Margin = new Thickness(22) };

        var head = new Grid { Margin = new Thickness(0, 0, 0, 14) };
        head.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        head.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

        var titles = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
        var title = new TextBlock
        {
            Text = $"Bảng lương tháng {payrollMonth:00}/{payrollYear}",
            FontSize = 24,
            FontWeight = FontWeights.SemiBold,
            Foreground = new SolidColorBrush(Color.FromRgb(32, 43, 61))
        };
        titles.Children.Add(title);
        titles.Children.Add(new TextBlock
        {
            Text = "Tổng hợp tiền công, OT, phụ cấp đêm, chủ nhật và các khoản khấu trừ của toàn bộ nhân viên.",
            Margin = new Thickness(0, 5, 0, 0),
            Foreground = new SolidColorBrush(Color.FromRgb(100, 108, 121))
        });
        head.Children.Add(titles);

        var tools = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
        tools.Children.Add(new TextBlock { Text = "Tháng", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 6, 0) });
        var monthBox = new ComboBox { Width = 74, Height = 34, Margin = new Thickness(0, 0, 10, 0) };
        for (int i = 1; i <= 12; i++) monthBox.Items.Add(i);
        monthBox.SelectedItem = payrollMonth;
        tools.Children.Add(monthBox);

        tools.Children.Add(new TextBlock { Text = "Năm", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 6, 0) });
        var yearBox = new ComboBox { Width = 90, Height = 34, Margin = new Thickness(0, 0, 14, 0) };
        for (int y = DateTime.Today.Year - 5; y <= DateTime.Today.Year + 5; y++) yearBox.Items.Add(y);
        if (!yearBox.Items.Contains(payrollYear)) yearBox.Items.Add(payrollYear);
        yearBox.SelectedItem = payrollYear;
        tools.Children.Add(yearBox);

        var export = new Button
        {
            Content = "▣  Xuất Excel",
            Padding = new Thickness(16, 8, 16, 8),
            Height = 36,
            Background = Brushes.White,
            Foreground = new SolidColorBrush(Color.FromRgb(21, 148, 71)),
            BorderBrush = new SolidColorBrush(Color.FromRgb(191, 220, 203)),
            FontWeight = FontWeights.SemiBold
        };
        tools.Children.Add(export);
        Grid.SetColumn(tools, 1);
        head.Children.Add(tools);
        DockPanel.SetDock(head, Dock.Top);
        root.Children.Add(head);

        var bottom = new Grid { Margin = new Thickness(0, 12, 0, 0) };
        bottom.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        bottom.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        bottom.Children.Add(new TextBlock
        {
            Text = "Nhấp đúp vào nhân viên để mở người đó trên Trang chủ.",
            VerticalAlignment = VerticalAlignment.Center,
            Foreground = new SolidColorBrush(Color.FromRgb(93, 102, 116))
        });
        var close = new Button { Content = "Đóng", Padding = new Thickness(20, 8, 20, 8) };
        close.Click += (_, __) => w.Close();
        Grid.SetColumn(close, 1);
        bottom.Children.Add(close);
        DockPanel.SetDock(bottom, Dock.Bottom);
        root.Children.Add(bottom);

        var list = new DataGrid
        {
            AutoGenerateColumns = false,
            IsReadOnly = true,
            SelectionMode = DataGridSelectionMode.Single,
            SelectionUnit = DataGridSelectionUnit.FullRow,
            CanUserAddRows = false,
            CanUserDeleteRows = false,
            CanUserResizeRows = false,
            HeadersVisibility = DataGridHeadersVisibility.Column,
            GridLinesVisibility = DataGridGridLinesVisibility.Horizontal,
            RowHeight = 42,
            ColumnHeaderHeight = 44,
            FontSize = 13,
            BorderBrush = new SolidColorBrush(Color.FromRgb(226, 231, 239)),
            BorderThickness = new Thickness(1),
            Background = Brushes.White,
            AlternatingRowBackground = new SolidColorBrush(Color.FromRgb(249, 251, 254)),
            HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto
        };

        Style rightStyle = new Style(typeof(TextBlock));
        rightStyle.Setters.Add(new Setter(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right));
        rightStyle.Setters.Add(new Setter(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center));
        rightStyle.Setters.Add(new Setter(TextBlock.MarginProperty, new Thickness(4, 0, 8, 0)));

        Style centerStyle = new Style(typeof(TextBlock));
        centerStyle.Setters.Add(new Setter(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Center));
        centerStyle.Setters.Add(new Setter(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center));

        void Col(string header, string binding, double width, bool right = false, bool center = false)
        {
            var c = new DataGridTextColumn
            {
                Header = header,
                Binding = new System.Windows.Data.Binding(binding),
                Width = new DataGridLength(width)
            };
            if (right) c.ElementStyle = rightStyle;
            else if (center) c.ElementStyle = centerStyle;
            list.Columns.Add(c);
        }

        Col("Mã NV", "Code", 88, center: true);
        Col("Nhân viên", "Name", 155);
        Col("Công hưởng lương", "PaidDays", 115, center: true);
        Col("Lương công", "BasePay", 125, right: true);
        Col("OT 150%", "Ot150Pay", 112, right: true);
        Col("Đêm 30%", "Night30Pay", 112, right: true);
        Col("OT 215%", "Ot215Pay", 112, right: true);
        Col("CN ngày", "SundayDayPay", 112, right: true);
        Col("CN đêm", "SundayNightPay", 112, right: true);
        Col("Chuyên cần", "Bonus", 112, right: true);
        Col("Tổng lương", "Gross", 125, right: true);
        Col("Bảo hiểm", "Insurance", 118, right: true);
        Col("Công đoàn", "UnionFee", 112, right: true);
        Col("THỰC NHẬN", "Net", 135, right: true);

        void ReloadPayroll()
        {
            payrollMonth = monthBox.SelectedItem is int m ? m : payrollMonth;
            payrollYear = yearBox.SelectedItem is int y ? y : payrollYear;
            title.Text = $"Bảng lương tháng {payrollMonth:00}/{payrollYear}";
            w.Title = $"Bảng lương  •  Tháng {payrollMonth:00}/{payrollYear}";

            var rows = data.Employees.Select(emp =>
            {
                var monthRows = data.Attendance.Where(x => x.EmployeeId == emp.Id && x.Date.Year == payrollYear && x.Date.Month == payrollMonth).ToList();
                var salary = SalaryCalculator.Calculate(emp, monthRows, payrollYear, payrollMonth, BonusCheck.IsChecked == true, data.Settings);
                decimal ot150Hours = 0m;
                decimal ot215Hours = 0m;
                foreach (var r in monthRows)
                {
                    if (r.Date.DayOfWeek == DayOfWeek.Sunday || r.OvertimeHours <= 0m || (r.Type != AttendanceType.Work && r.Type != AttendanceType.OvertimeOnly)) continue;
                    if (r.Shift == ShiftType.Night)
                    {
                        ot150Hours += Math.Min(r.OvertimeHours, 2m);
                        ot215Hours += Math.Max(r.OvertimeHours - 2m, 0m);
                    }
                    else ot150Hours += r.OvertimeHours;
                }
                decimal otHourly = (emp.OvertimeBase > 0 ? emp.OvertimeBase : 7_000_000m) / (data.Settings.StandardDays > 0 ? data.Settings.StandardDays : 26m) / 8m;
                decimal ot150Pay = otHourly * ot150Hours * data.Settings.NormalOvertimeRate;
                decimal ot215Pay = otHourly * ot215Hours * data.Settings.NightOvertimeAfter2Rate;
                return new PayrollRow
                {
                    Employee = emp,
                    Code = emp.Code,
                    Name = emp.Name,
                    PaidDaysValue = salary.PaidDays,
                    BasePayValue = salary.BasePay,
                    Ot150PayValue = ot150Pay,
                    Night30PayValue = salary.NightExtraPay,
                    Ot215PayValue = ot215Pay,
                    SundayDayPayValue = salary.SundayDayPay,
                    SundayNightPayValue = salary.SundayNightPay,
                    BonusValue = salary.AttendanceBonus,
                    GrossValue = salary.Gross,
                    InsuranceValue = salary.Insurance,
                    UnionFeeValue = salary.UnionFee,
                    NetValue = salary.Net
                };
            }).ToList();

            list.ItemsSource = rows;
        }

        list.MouseDoubleClick += (_, __) =>
        {
            if (list.SelectedItem is PayrollRow r && !r.IsTotal && r.Employee != null)
            {
                current = r.Employee;
                w.Close();
                RefreshAll();
            }
        };

        monthBox.SelectionChanged += (_, __) => { if (w.IsLoaded) ReloadPayroll(); };
        yearBox.SelectionChanged += (_, __) => { if (w.IsLoaded) ReloadPayroll(); };

        export.Click += (_, __) =>
        {
            var dlg = new SaveFileDialog
            {
                Title = "Xuất bảng lương Excel",
                Filter = "Excel Workbook (*.xlsx)|*.xlsx",
                FileName = $"BangLuong_Thang_{payrollMonth:00}{payrollYear}.xlsx",
                AddExtension = true,
                DefaultExt = ".xlsx"
            };
            if (dlg.ShowDialog(w) != true) return;
            try
            {
                ExcelExporter.Export(dlg.FileName, data, payrollYear, payrollMonth, BonusCheck.IsChecked == true);
                MessageBox.Show($"Đã xuất Excel tháng {payrollMonth:00}/{payrollYear}.\n\n{dlg.FileName}", "Xuất Excel", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể xuất Excel:\n" + ex.Message, "Xuất Excel", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        };

        root.Children.Add(list);
        w.Content = root;
        w.Loaded += (_, __) => ReloadPayroll();
        w.ShowDialog();
    }

    void Employees_Click(object? s,RoutedEventArgs e)
    {
        var w=DialogWindow($"Nhân viên  •  Tháng {Month:00}/{Year}",1180,650);
        w.MinWidth=1000; w.MinHeight=580;
        var root=new DockPanel{Margin=new Thickness(20)};

        var head=new Grid{Margin=new Thickness(0,0,0,14)};
        head.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star)});
        head.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});
        var titles=new StackPanel();
        titles.Children.Add(new TextBlock{Text=$"Nhân viên  •  Tháng {Month:00}/{Year}",FontSize=21,FontWeight=FontWeights.SemiBold,Foreground=new SolidColorBrush(Color.FromRgb(32,43,61))});
        titles.Children.Add(new TextBlock{Text="Tổng hợp ngày công, nghỉ phép, OT 150%, phụ cấp đêm 30%, OT 215%, chủ nhật và lương tạm tính",Margin=new Thickness(0,4,0,0),Foreground=new SolidColorBrush(Color.FromRgb(100,108,121))});
        head.Children.Add(titles);
        var add=new Button{Content="＋  Thêm nhân viên",Padding=new Thickness(16,9,16,9),Background=new SolidColorBrush(Color.FromRgb(47,118,241)),Foreground=Brushes.White,BorderThickness=new Thickness(0)};
        Grid.SetColumn(add,1);head.Children.Add(add);DockPanel.SetDock(head,Dock.Top);root.Children.Add(head);

        var bottom=new Grid{Margin=new Thickness(0,12,0,0)};
        bottom.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star)});
        bottom.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});
        var hint=new TextBlock{Text="Nhấp đúp vào nhân viên để chuyển sang người đó trên Trang chủ.",VerticalAlignment=VerticalAlignment.Center,Foreground=new SolidColorBrush(Color.FromRgb(93,102,116))};
        bottom.Children.Add(hint);
        var actions=new StackPanel{Orientation=Orientation.Horizontal};
        var edit=new Button{Content="Sửa thông tin",Margin=new Thickness(4,0,4,0),Padding=new Thickness(14,8,14,8)};
        var del=new Button{Content="Xóa",Margin=new Thickness(4,0,4,0),Padding=new Thickness(14,8,14,8),Foreground=new SolidColorBrush(Color.FromRgb(205,65,65))};
        var open=new Button{Content="Mở nhân viên",Margin=new Thickness(4,0,0,0),Padding=new Thickness(14,8,14,8)};
        actions.Children.Add(edit);actions.Children.Add(del);actions.Children.Add(open);Grid.SetColumn(actions,1);bottom.Children.Add(actions);
        DockPanel.SetDock(bottom,Dock.Bottom);root.Children.Add(bottom);

        var list=new DataGrid{AutoGenerateColumns=false,IsReadOnly=true,SelectionMode=DataGridSelectionMode.Single,SelectionUnit=DataGridSelectionUnit.FullRow,CanUserAddRows=false,CanUserDeleteRows=false,CanUserResizeRows=false,HeadersVisibility=DataGridHeadersVisibility.Column,GridLinesVisibility=DataGridGridLinesVisibility.Horizontal,RowHeight=38,ColumnHeaderHeight=40,BorderBrush=new SolidColorBrush(Color.FromRgb(226,231,239)),BorderThickness=new Thickness(1),Background=Brushes.White,AlternatingRowBackground=new SolidColorBrush(Color.FromRgb(249,251,254))};
        void Col(string header,string binding,double width,bool star=false)
        {
            list.Columns.Add(new DataGridTextColumn{Header=header,Binding=new System.Windows.Data.Binding(binding),Width=star?new DataGridLength(width,DataGridLengthUnitType.Star):new DataGridLength(width)});
        }
        Col("Mã NV","Code",78); Col("Nhân viên","Name",1,true); Col("Ngày công","Worked",78); Col("Nghỉ phép","Leave",75); Col("OT 150% (giờ)","Ot150",92); Col("Đêm 30% (giờ)","Night30",92); Col("OT 215% (giờ)","Ot215",92); Col("CN ngày (giờ)","SundayDay",88); Col("CN đêm (giờ)","SundayNight",88); Col("Phép còn","LeaveBalance",75); Col("Lương tạm tính","Net",120);
        root.Children.Add(list);

        void reload()
        {
            list.ItemsSource=data.Employees.Select(emp=>
            {
                var monthRows=data.Attendance.Where(x=>x.EmployeeId==emp.Id&&x.Date.Year==Year&&x.Date.Month==Month).ToList();
                var salary=SalaryCalculator.Calculate(emp,monthRows,Year,Month,BonusCheck.IsChecked==true,data.Settings);
                decimal ot150=0m;
                decimal ot215=0m;
                decimal night30=0m;
                decimal sundayDay=0m;
                decimal sundayNight=0m;

                foreach(var r in monthRows)
                {
                    bool sunday=r.Date.DayOfWeek==DayOfWeek.Sunday;
                    if(sunday)
                    {
                        if(r.Type is AttendanceType.Work or AttendanceType.OvertimeOnly)
                        {
                            decimal h=r.OvertimeHours>0?r.OvertimeHours:(r.Type==AttendanceType.Work?data.Settings.SundayDefaultHours:0m);
                            if(r.Shift==ShiftType.Night) sundayNight+=h;
                            else sundayDay+=h;
                        }
                        continue;
                    }

                    if(r.Type==AttendanceType.Work&&r.Shift==ShiftType.Night)
                        night30+=data.Settings.NightExtraHours;

                    if(r.OvertimeHours<=0 || (r.Type!=AttendanceType.Work&&r.Type!=AttendanceType.OvertimeOnly))
                        continue;

                    if(r.Shift==ShiftType.Night)
                    {
                        ot150+=Math.Min(r.OvertimeHours,2m);
                        ot215+=Math.Max(r.OvertimeHours-2m,0m);
                    }
                    else
                    {
                        ot150+=r.OvertimeHours;
                    }
                }

                return new EmployeeRow{
                    x=emp,Code=emp.Code,Name=emp.Name,
                    Worked=salary.WorkedDays.ToString("0.#"),
                    Leave=salary.LeaveDays.ToString("0.#"),
                    Ot150=ot150.ToString("0.#"),
                    Night30=night30.ToString("0.#"),
                    Ot215=ot215.ToString("0.#"),
                    SundayDay=sundayDay.ToString("0.#"),
                    SundayNight=sundayNight.ToString("0.#"),
                    LeaveBalance=emp.AnnualLeaveBalance.ToString("0.#"),
                    Net=Money(salary.Net)
                };
            }).ToList();
        }
        reload();

        void OpenSelected(){if(list.SelectedItem is EmployeeRow r){current=r.x;w.Close();RefreshAll();}}
        list.MouseDoubleClick+=(_,__)=>OpenSelected();
        add.Click+=(_,__)=>{if(data.Employees.Count>=5){MessageBox.Show("App giới hạn tối đa 5 người.");return;}var emp=new Employee{Code=$"NV{data.Employees.Count+1:00}",LastLeaveAccrualDate=DateTime.Today};if(EditEmployee(emp,true)){data.Employees.Add(emp);store.Save(data);reload();RefreshAll();}};
        edit.Click+=(_,__)=>{if(list.SelectedItem is EmployeeRow r&&EditEmployee(r.x,false)){store.Save(data);reload();RefreshAll();}};
        del.Click+=(_,__)=>{if(list.SelectedItem is not EmployeeRow r)return;if(data.Employees.Count<=1){MessageBox.Show("Phải giữ lại ít nhất 1 nhân viên.");return;}if(MessageBox.Show("Xóa nhân viên và toàn bộ chấm công của người này?","Xác nhận",MessageBoxButton.YesNo)==MessageBoxResult.Yes){data.Attendance.RemoveAll(x=>x.EmployeeId==r.x.Id);data.Employees.Remove(r.x);if(current.Id==r.x.Id)current=data.Employees[0];store.Save(data);reload();RefreshAll();}};
        open.Click+=(_,__)=>OpenSelected();
        w.Content=root;w.ShowDialog();
    }

    bool EditEmployee(Employee emp,bool isNew){var w=DialogWindow(isNew?"Thêm nhân viên":"Sửa nhân viên",440,520);var sp=new StackPanel{Margin=new Thickness(24)};TextBox AddText(string label,string val){sp.Children.Add(new TextBlock{Text=label,Margin=new Thickness(0,7,0,4)});var tb=new TextBox{Text=val,Height=32};sp.Children.Add(tb);return tb;}var code=AddText("Mã nhân viên",emp.Code);var name=AddText("Tên nhân viên",isNew?"":emp.Name);var sal=AddText("Lương tính công",emp.SalaryBase.ToString("0"));var ot=AddText("Lương tính tăng ca",emp.OvertimeBase.ToString("0"));var leave=AddText("Phép năm còn lại",emp.AnnualLeaveBalance.ToString("0.#"));sp.Children.Add(new TextBlock{Text=$"Ngày {data.Settings.LeaveAccrualDay} hàng tháng tự +{data.Settings.LeaveAccrualAmount:0.#} phép",Foreground=new SolidColorBrush(Color.FromRgb(47,118,241)),Margin=new Thickness(0,8,0,10)});var save=new Button{Content="Lưu",Background=new SolidColorBrush(Color.FromRgb(47,118,241)),Foreground=Brushes.White};bool ok=false;save.Click+=(_,__)=>{if(string.IsNullOrWhiteSpace(code.Text)||string.IsNullOrWhiteSpace(name.Text)){MessageBox.Show("Nhập đủ mã và tên.");return;}if(data.Employees.Any(x=>x.Id!=emp.Id&&x.Code.Equals(code.Text.Trim(),StringComparison.OrdinalIgnoreCase))){MessageBox.Show("Mã nhân viên đã tồn tại.");return;}if(!decimal.TryParse(sal.Text,out var sv)||!decimal.TryParse(ot.Text,out var ov)||!decimal.TryParse(leave.Text.Replace(',', '.'),NumberStyles.Any,CultureInfo.InvariantCulture,out var lv)){MessageBox.Show("Số tiền/phép không hợp lệ.");return;}emp.Code=code.Text.Trim();emp.Name=name.Text.Trim();emp.SalaryBase=sv;emp.OvertimeBase=ov;emp.AnnualLeaveBalance=lv;if(isNew&&emp.LastLeaveAccrualDate==null)emp.LastLeaveAccrualDate=DateTime.Today;ok=true;w.Close();};sp.Children.Add(save);w.Content=sp;w.ShowDialog();return ok;}
    void Settings_Click(object s,RoutedEventArgs e)
    {
        var w=DialogWindow("Cài đặt",720,720);
        w.ResizeMode=ResizeMode.CanResize; w.MinWidth=680; w.MinHeight=650;
        var root=new DockPanel{Margin=new Thickness(22)};
        var title=new StackPanel{Margin=new Thickness(0,0,0,14)};
        title.Children.Add(new TextBlock{Text="Cài đặt ứng dụng",FontSize=23,FontWeight=FontWeights.SemiBold,Foreground=new SolidColorBrush(Color.FromRgb(32,43,61))});
        title.Children.Add(new TextBlock{Text="Quy tắc lương, phép năm và sao lưu dữ liệu",Margin=new Thickness(0,4,0,0),Foreground=new SolidColorBrush(Color.FromRgb(100,108,121))});
        DockPanel.SetDock(title,Dock.Top); root.Children.Add(title);

        var footer=new Grid{Margin=new Thickness(0,14,0,0)};
        footer.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star)});
        footer.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});
        var pathText=new TextBlock{Text=$"Dữ liệu: {store.FilePath}",VerticalAlignment=VerticalAlignment.Center,Foreground=new SolidColorBrush(Color.FromRgb(120,128,140)),FontSize=12,TextTrimming=TextTrimming.CharacterEllipsis};
        footer.Children.Add(pathText);
        var footerButtons=new StackPanel{Orientation=Orientation.Horizontal};
        var cancel=new Button{Content="Đóng",Padding=new Thickness(18,8,18,8),Margin=new Thickness(5,0,0,0)};
        var save=new Button{Content="Lưu cài đặt",Padding=new Thickness(18,8,18,8),Margin=new Thickness(8,0,0,0),Background=new SolidColorBrush(Color.FromRgb(47,118,241)),Foreground=Brushes.White,BorderThickness=new Thickness(0)};
        footerButtons.Children.Add(cancel); footerButtons.Children.Add(save); Grid.SetColumn(footerButtons,1); footer.Children.Add(footerButtons);
        DockPanel.SetDock(footer,Dock.Bottom); root.Children.Add(footer);

        var scroll=new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto};
        var body=new StackPanel(); scroll.Content=body; root.Children.Add(scroll);

        Border Section(string header)
        {
            var b=new Border{BorderBrush=new SolidColorBrush(Color.FromRgb(226,231,239)),BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(10),Background=Brushes.White,Padding=new Thickness(16),Margin=new Thickness(0,0,0,12)};
            var sp=new StackPanel(); sp.Children.Add(new TextBlock{Text=header,FontSize=17,FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,0,0,10),Foreground=new SolidColorBrush(Color.FromRgb(32,43,61))}); b.Child=sp; body.Children.Add(b); return b;
        }
        TextBox SettingBox(StackPanel sp,string label,string value,string hint="")
        {
            var g=new Grid{Margin=new Thickness(0,4,0,7)}; g.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(260)}); g.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(150)}); g.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star)});
            var l=new TextBlock{Text=label,VerticalAlignment=VerticalAlignment.Center}; g.Children.Add(l);
            var tb=new TextBox{Text=value,Height=30,VerticalContentAlignment=VerticalAlignment.Center,Padding=new Thickness(8,0,8,0)}; Grid.SetColumn(tb,1); g.Children.Add(tb);
            if(!string.IsNullOrWhiteSpace(hint)){var h=new TextBlock{Text=hint,Foreground=new SolidColorBrush(Color.FromRgb(130,138,150)),VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(10,0,0,0)};Grid.SetColumn(h,2);g.Children.Add(h);}
            sp.Children.Add(g); return tb;
        }

        var salarySection=(StackPanel)Section("Quy tắc lương").Child;
        var standard=SettingBox(salarySection,"Công chuẩn chia lương",data.Settings.StandardDays.ToString("0.##"),"ngày");
        var bonus=SettingBox(salarySection,"Thưởng chuyên cần",data.Settings.AttendanceBonus.ToString("0"),"đ");
        var insurance=SettingBox(salarySection,"Bảo hiểm",(data.Settings.InsuranceRate*100m).ToString("0.##"),"%");
        var union=SettingBox(salarySection,"Công đoàn",(data.Settings.UnionRate*100m).ToString("0.##"),"%");
        var normalOt=SettingBox(salarySection,"Tăng ca ngày thường",(data.Settings.NormalOvertimeRate*100m).ToString("0.##"),"%");
        var sundayDay=SettingBox(salarySection,"Chủ nhật ca ngày",(data.Settings.SundayDayRate*100m).ToString("0.##"),"%");
        var sundayNight=SettingBox(salarySection,"Chủ nhật ca đêm",(data.Settings.SundayNightRate*100m).ToString("0.##"),"%");
        var nightExtra=SettingBox(salarySection,"Phụ cấp ca đêm",(data.Settings.NightExtraRate*100m).ToString("0.##"),$"% × {data.Settings.NightExtraHours:0.#} giờ");
        var nightAfter2=SettingBox(salarySection,"OT đêm từ giờ thứ 3",(data.Settings.NightOvertimeAfter2Rate*100m).ToString("0.##"),"%");
        var sundayHours=SettingBox(salarySection,"Giờ mặc định Chủ nhật",data.Settings.SundayDefaultHours.ToString("0.##"),"giờ");

        var leaveSection=(StackPanel)Section("Phép năm").Child;
        var leaveDay=SettingBox(leaveSection,"Ngày tự cộng phép hàng tháng",data.Settings.LeaveAccrualDay.ToString(),"ngày trong tháng");
        var leaveAmount=SettingBox(leaveSection,"Số phép được cộng",data.Settings.LeaveAccrualAmount.ToString("0.##"),"ngày phép");
        leaveSection.Children.Add(new TextBlock{Text="Nếu ngày cộng phép đã qua mà app chưa được mở, lần mở tiếp theo vẫn tự cộng bù.",TextWrapping=TextWrapping.Wrap,Foreground=new SolidColorBrush(Color.FromRgb(47,118,241)),Margin=new Thickness(0,5,0,0)});

        var dataSection=(StackPanel)Section("Dữ liệu").Child;
        dataSection.Children.Add(new TextBlock{Text="GitHub là nguồn dữ liệu chính. Máy chỉ lưu cấu hình kết nối/token; có thể sao lưu JSON thủ công khi cần.",TextWrapping=TextWrapping.Wrap,Foreground=new SolidColorBrush(Color.FromRgb(100,108,121)),Margin=new Thickness(0,0,0,10)});
        var dataButtons=new StackPanel{Orientation=Orientation.Horizontal};
        var backup=new Button{Content="Sao lưu dữ liệu",Padding=new Thickness(16,8,16,8),Margin=new Thickness(0,0,8,0)};
        var restore=new Button{Content="Khôi phục dữ liệu",Padding=new Thickness(16,8,16,8)};
        dataButtons.Children.Add(backup); dataButtons.Children.Add(restore); dataSection.Children.Add(dataButtons);

        var gh=store.LoadGitHubSettings();
        var githubSection=(StackPanel)Section("Đồng bộ GitHub").Child;
        githubSection.Children.Add(new TextBlock{Text="Repo dữ liệu: https://github.com/kendevill/chamcong-data",TextWrapping=TextWrapping.Wrap,Foreground=new SolidColorBrush(Color.FromRgb(47,118,241)),Margin=new Thickness(0,0,0,8)});
        var ghOwner=SettingBox(githubSection,"GitHub owner",string.IsNullOrWhiteSpace(gh.Owner)?"kendevill":gh.Owner);
        var ghRepo=SettingBox(githubSection,"Repository",string.IsNullOrWhiteSpace(gh.Repo)?"chamcong-data":gh.Repo);
        var ghBranch=SettingBox(githubSection,"Branch",string.IsNullOrWhiteSpace(gh.Branch)?"main":gh.Branch);
        var ghPath=SettingBox(githubSection,"File dữ liệu",string.IsNullOrWhiteSpace(gh.Path)?"data.json":gh.Path);
        githubSection.Children.Add(new TextBlock{Text="Fine-grained token (Contents: Read and write)",Margin=new Thickness(0,5,0,4)});
        var ghToken=new PasswordBox{Password=gh.Token ?? "",Height=32,Padding=new Thickness(8,4,8,4)}; githubSection.Children.Add(ghToken);
        var ghEnabled=new CheckBox{Content="Bật tự động đồng bộ GitHub",IsChecked=gh.Enabled,Margin=new Thickness(0,10,0,10),FontWeight=FontWeights.SemiBold}; githubSection.Children.Add(ghEnabled);
        var ghButtons=new StackPanel{Orientation=Orientation.Horizontal};
        var ghTest=new Button{Content="Kiểm tra kết nối",Padding=new Thickness(16,8,16,8),Margin=new Thickness(0,0,8,0)};
        var ghPull=new Button{Content="Tải dữ liệu từ GitHub",Padding=new Thickness(16,8,16,8),Margin=new Thickness(0,0,8,0)};
        var ghPush=new Button{Content="Đẩy dữ liệu lên GitHub",Padding=new Thickness(16,8,16,8)};
        ghButtons.Children.Add(ghTest);ghButtons.Children.Add(ghPull);ghButtons.Children.Add(ghPush);githubSection.Children.Add(ghButtons);
        githubSection.Children.Add(new TextBlock{Text="App vẫn giữ data.json local làm bản dự phòng. Mất mạng vẫn dùng bình thường; khi lưu có mạng app sẽ cập nhật repo.",TextWrapping=TextWrapping.Wrap,Foreground=new SolidColorBrush(Color.FromRgb(100,108,121)),Margin=new Thickness(0,10,0,0)});

        GitHubSyncSettings ReadGitHubForm() => new()
        {
            Owner=ghOwner.Text.Trim(), Repo=ghRepo.Text.Trim(), Branch=ghBranch.Text.Trim(), Path=ghPath.Text.Trim(), Token=ghToken.Password.Trim(), Enabled=ghEnabled.IsChecked==true
        };
        ghTest.Click+=async (_,__)=>
        {
            try
            {
                var cfg=ReadGitHubForm();
                if(string.IsNullOrWhiteSpace(cfg.Token)){MessageBox.Show("Hãy nhập GitHub token trước.","GitHub");return;}
                var temp=Path.Combine(Path.GetTempPath(),"ChamCongTinhLuong_github_test.json");
                await GitHubSync.DownloadAsync(cfg,temp);
                try{File.Delete(temp);}catch{}
                MessageBox.Show("Kết nối GitHub thành công ✓","GitHub");
            }
            catch(Exception ex){MessageBox.Show("Kết nối GitHub thất bại:\n"+ex.Message,"GitHub",MessageBoxButton.OK,MessageBoxImage.Error);}
        };
        ghPull.Click+=async (_,__)=>
        {
            try
            {
                var cfg=ReadGitHubForm(); store.SaveGitHubSettings(cfg);
                if(MessageBox.Show("Tải lại data.json mới nhất từ GitHub. Tiếp tục?","GitHub",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;
                store.SaveGitHubSettings(cfg); data=store.Load(); current=data.Employees.First(); RefreshAll();
                MessageBox.Show("Đã tải dữ liệu từ GitHub.","GitHub");
            }
            catch(Exception ex){MessageBox.Show("Không thể tải dữ liệu:\n"+ex.Message,"GitHub",MessageBoxButton.OK,MessageBoxImage.Error);}
        };
        ghPush.Click+=async (_,__)=>
        {
            try
            {
                var cfg=ReadGitHubForm(); store.SaveGitHubSettings(cfg); store.SaveGitHubSettings(cfg); store.Save(data);
                MessageBox.Show("Đã đẩy data.json lên GitHub.","GitHub");
            }
            catch(Exception ex){MessageBox.Show("Không thể đẩy dữ liệu:\n"+ex.Message,"GitHub",MessageBoxButton.OK,MessageBoxImage.Error);}
        };

        decimal? D(TextBox tb){return decimal.TryParse(tb.Text.Replace(',', '.'),NumberStyles.Any,CultureInfo.InvariantCulture,out var v)?v:null;}
        backup.Click+=(_,__)=>
        {
            store.Save(data);
            var dlg=new SaveFileDialog{Filter="JSON (*.json)|*.json",FileName=$"ChamCongTinhLuong_Backup_{DateTime.Now:yyyyMMdd_HHmm}.json"};
            if(dlg.ShowDialog(w)==true){File.WriteAllText(dlg.FileName,store.ExportJson(data));MessageBox.Show("Đã sao lưu dữ liệu.","Sao lưu");}
        };
        restore.Click+=(_,__)=>
        {
            var dlg=new OpenFileDialog{Filter="JSON (*.json)|*.json|Tất cả file (*.*)|*.*"};
            if(dlg.ShowDialog(w)!=true)return;
            if(MessageBox.Show("Khôi phục sẽ thay thế dữ liệu hiện tại. Tiếp tục?","Xác nhận",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;
            try{data=store.ImportJson(File.ReadAllText(dlg.FileName));current=data.Employees.First();ApplyMonthlyLeaveAccrual(DateTime.Today);store.Save(data);RefreshAll();MessageBox.Show("Đã khôi phục dữ liệu.","Khôi phục");w.Close();}
            catch(Exception ex){MessageBox.Show("Không thể khôi phục: "+ex.Message);}
        };
        cancel.Click+=(_,__)=>w.Close();
        save.Click+=(_,__)=>
        {
            var sd=D(standard);var bo=D(bonus);var ins=D(insurance);var un=D(union);var no=D(normalOt);var sday=D(sundayDay);var snight=D(sundayNight);var ne=D(nightExtra);var na=D(nightAfter2);var sh=D(sundayHours);var la=D(leaveAmount);
            if(!int.TryParse(leaveDay.Text,out var ld)||ld<1||ld>28||sd is null||sd<=0||bo is null||bo<0||ins is null||ins<0||un is null||un<0||no is null||no<=0||sday is null||sday<=0||snight is null||snight<=0||ne is null||ne<0||na is null||na<=0||sh is null||sh<=0||la is null||la<0){MessageBox.Show("Có giá trị cài đặt không hợp lệ. Ngày cộng phép phải từ 1 đến 28.");return;}
            data.Settings.StandardDays=sd.Value; data.Settings.AttendanceBonus=bo.Value; data.Settings.InsuranceRate=ins.Value/100m; data.Settings.UnionRate=un.Value/100m; data.Settings.NormalOvertimeRate=no.Value/100m; data.Settings.SundayDayRate=sday.Value/100m; data.Settings.SundayNightRate=snight.Value/100m; data.Settings.NightExtraRate=ne.Value/100m; data.Settings.NightOvertimeAfter2Rate=na.Value/100m; data.Settings.SundayDefaultHours=sh.Value; data.Settings.LeaveAccrualDay=ld; data.Settings.LeaveAccrualAmount=la.Value;
            var ghCfg=ReadGitHubForm(); store.SaveGitHubSettings(ghCfg);
            store.Save(data);RefreshAll();MessageBox.Show("Đã lưu cài đặt.","Cài đặt");w.Close();
        };
        w.Content=root; w.ShowDialog();
    }

    bool ApplyMonthlyLeaveAccrual(DateTime today)
    {
        bool changed=false; int accrualDay=Math.Clamp(data.Settings.LeaveAccrualDay,1,28); decimal amount=Math.Max(0m,data.Settings.LeaveAccrualAmount);
        foreach(var employee in data.Employees)
        {
            if(employee.LastLeaveAccrualDate is null){employee.LastLeaveAccrualDate=today.Date;changed=true;continue;}
            var cursor=employee.LastLeaveAccrualDate.Value.Date; var month=new DateTime(cursor.Year,cursor.Month,1); var end=new DateTime(today.Year,today.Month,1);
            while(month<=end){var day=new DateTime(month.Year,month.Month,accrualDay);if(day>cursor&&day<=today.Date){employee.AnnualLeaveBalance+=amount;cursor=day;changed=true;}month=month.AddMonths(1);}
            if(employee.LastLeaveAccrualDate.Value.Date!=cursor){employee.LastLeaveAccrualDate=cursor;changed=true;}
        }
        return changed;
    }
    static string Initials(string n){var p=n.Split(' ',StringSplitOptions.RemoveEmptyEntries);if(p.Length==0)return"NV";if(p.Length==1)return p[0][..Math.Min(2,p[0].Length)].ToUpperInvariant();return($"{p[0][0]}{p[^1][0]}").ToUpperInvariant();}
    static string Money(decimal v)=>string.Format(new CultureInfo("vi-VN"),"{0:N0} đ",Math.Round(v));
    sealed class PayrollRow
    {
        public Employee? Employee { get; set; }
        public bool IsTotal { get; set; }
        public string Code { get; set; } = "";
        public string Name { get; set; } = "";
        public decimal PaidDaysValue { get; set; }
        public decimal BasePayValue { get; set; }
        public decimal Ot150PayValue { get; set; }
        public decimal Night30PayValue { get; set; }
        public decimal Ot215PayValue { get; set; }
        public decimal SundayDayPayValue { get; set; }
        public decimal SundayNightPayValue { get; set; }
        public decimal BonusValue { get; set; }
        public decimal GrossValue { get; set; }
        public decimal InsuranceValue { get; set; }
        public decimal UnionFeeValue { get; set; }
        public decimal NetValue { get; set; }
        public string PaidDays => PaidDaysValue.ToString("0.#");
        public string BasePay => Money(BasePayValue);
        public string Ot150Pay => Money(Ot150PayValue);
        public string Night30Pay => Money(Night30PayValue);
        public string Ot215Pay => Money(Ot215PayValue);
        public string SundayDayPay => Money(SundayDayPayValue);
        public string SundayNightPay => Money(SundayNightPayValue);
        public string Bonus => Money(BonusValue);
        public string Gross => Money(GrossValue);
        public string Insurance => "-" + Money(InsuranceValue);
        public string UnionFee => "-" + Money(UnionFeeValue);
        public string Net => Money(NetValue);
    }

    sealed class EmployeeRow
    {
        public Employee x { get; set; } = null!;
        public string Code { get; set; } = "";
        public string Name { get; set; } = "";
        public string Worked { get; set; } = "";
        public string Leave { get; set; } = "";
        public string Ot150 { get; set; } = "";
        public string Night30 { get; set; } = "";
        public string Ot215 { get; set; } = "";
        public string SundayDay { get; set; } = "";
        public string SundayNight { get; set; } = "";
        public string LeaveBalance { get; set; } = "";
        public string Net { get; set; } = "";
    }
}
