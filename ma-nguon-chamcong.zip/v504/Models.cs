using System;
using System.Collections.Generic;

namespace ChamCongTinhLuong;

public sealed class Employee
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = "Nhân viên 1";
    public string Department { get; set; } = "Cá nhân";
    public string Code { get; set; } = "NV01";
    public decimal SalaryBase { get; set; } = 8_500_000m;
    public decimal OvertimeBase { get; set; } = 7_000_000m;
    public decimal AnnualLeaveBalance { get; set; } = 0m;
    public DateTime? LastLeaveAccrualDate { get; set; }
    public override string ToString() => Name;
}

public enum AttendanceType { Work = 0, PaidLeave = 1, OvertimeOnly = 2, Holiday = 3 }
public enum ShiftType { Day, Night }

public sealed class AttendanceRecord
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid EmployeeId { get; set; }
    public DateTime Date { get; set; }
    public AttendanceType Type { get; set; }
    public ShiftType Shift { get; set; }
    public decimal OvertimeHours { get; set; }
    // Số ngày công hưởng lương của dòng này. Dữ liệu cũ mặc định vẫn là 1 ngày.
    public decimal PaidDayUnits { get; set; } = 1m;
    public string Note { get; set; } = "";
}

public sealed class AppSettings
{
    public decimal StandardDays { get; set; } = 26m;
    public decimal AttendanceBonus { get; set; } = 400_000m;
    public decimal InsuranceRate { get; set; } = 0.105m;
    public decimal UnionRate { get; set; } = 0.005m;
    public decimal NormalOvertimeRate { get; set; } = 1.50m;
    public decimal SundayDayRate { get; set; } = 2.00m;
    public decimal SundayNightRate { get; set; } = 2.80m;
    public decimal NightExtraRate { get; set; } = 0.30m;
    public decimal NightOvertimeAfter2Rate { get; set; } = 2.15m;
    public decimal NightExtraHours { get; set; } = 6m;
    public decimal SundayDefaultHours { get; set; } = 11m;
    public int LeaveAccrualDay { get; set; } = 16;
    public decimal LeaveAccrualAmount { get; set; } = 1m;
}

public sealed class AppData
{
    public List<Employee> Employees { get; set; } = new();
    public List<AttendanceRecord> Attendance { get; set; } = new();
    public AppSettings Settings { get; set; } = new();
}

public sealed class SalaryResult
{
    public int CalendarWorkDays { get; set; }
    public decimal PaidDays { get; set; }
    public decimal WorkedDays { get; set; }
    public decimal LeaveDays { get; set; }
    public decimal BasePay { get; set; }
    public decimal DayOtPay { get; set; }
    public decimal NightOtPay { get; set; }
    public decimal NightExtraPay { get; set; }
    public decimal SundayDayPay { get; set; }
    public decimal SundayNightPay { get; set; }
    public decimal SundayPay => SundayDayPay + SundayNightPay;
    public decimal AttendanceBonus { get; set; }
    public decimal Insurance { get; set; }
    public decimal UnionFee { get; set; }
    public decimal Gross { get; set; }
    public decimal Net { get; set; }
}
