using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security;
using System.Text;

namespace ChamCongTinhLuong;

public static class ExcelExporter
{
    public static void Export(string filePath, AppData data, int year, int month, bool includeBonus)
    {
        var employees = data.Employees.OrderBy(x => x.Code).ToList();
        if (employees.Count == 0) throw new InvalidOperationException("Chưa có nhân viên để xuất bảng lương.");

        using var fs = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None);
        using var zip = new ZipArchive(fs, ZipArchiveMode.Create);

        Write(zip, "[Content_Types].xml", ContentTypes(employees.Count));
        Write(zip, "_rels/.rels", RootRels());
        Write(zip, "xl/workbook.xml", WorkbookXml(employees));
        Write(zip, "xl/_rels/workbook.xml.rels", WorkbookRels(employees.Count));
        Write(zip, "xl/styles.xml", StylesXml());

        for (int i = 0; i < employees.Count; i++)
        {
            var emp = employees[i];
            var monthRows = data.Attendance
                .Where(x => x.EmployeeId == emp.Id && x.Date.Year == year && x.Date.Month == month)
                .ToList();
            Write(zip, $"xl/worksheets/sheet{i + 1}.xml", EmployeeSheetXml(emp, monthRows, data.Settings, year, month, includeBonus));
        }
    }

    static string EmployeeSheetXml(Employee emp, List<AttendanceRecord> rows, AppSettings settings, int year, int month, bool includeBonus)
    {
        var s = SalaryCalculator.Calculate(emp, rows, year, month, includeBonus, settings);
        decimal standardDays = settings.StandardDays > 0 ? settings.StandardDays : 26m;
        decimal salaryBase = emp.SalaryBase > 0 ? emp.SalaryBase : 8_500_000m;
        decimal otBase = emp.OvertimeBase > 0 ? emp.OvertimeBase : 7_000_000m;
        decimal hourly = otBase / standardDays / 8m;

        decimal normalDayHours = 0m;
        decimal sundayDayHours = 0m;
        decimal nightExtraHours = 0m;
        decimal night150Hours = 0m;
        decimal night215Hours = 0m;
        decimal sundayNightHours = 0m;

        foreach (var r in rows)
        {
            bool sunday = r.Date.DayOfWeek == DayOfWeek.Sunday;
            if (r.Type == AttendanceType.Work)
            {
                if (sunday)
                {
                    decimal h = r.OvertimeHours > 0 ? r.OvertimeHours : settings.SundayDefaultHours;
                    if (r.Shift == ShiftType.Night) sundayNightHours += h;
                    else sundayDayHours += h;
                }
                else
                {
                    if (r.Shift == ShiftType.Night)
                    {
                        nightExtraHours += settings.NightExtraHours;
                        if (r.OvertimeHours > 0)
                        {
                            night150Hours += Math.Min(r.OvertimeHours, 2m);
                            night215Hours += Math.Max(r.OvertimeHours - 2m, 0m);
                        }
                    }
                    else if (r.OvertimeHours > 0) normalDayHours += r.OvertimeHours;
                }
            }
            else if (r.Type == AttendanceType.OvertimeOnly)
            {
                if (sunday)
                {
                    if (r.Shift == ShiftType.Night) sundayNightHours += r.OvertimeHours;
                    else sundayDayHours += r.OvertimeHours;
                }
                else if (r.Shift == ShiftType.Night)
                {
                    night150Hours += Math.Min(r.OvertimeHours, 2m);
                    night215Hours += Math.Max(r.OvertimeHours - 2m, 0m);
                }
                else normalDayHours += r.OvertimeHours;
            }
        }

        decimal night150Pay = hourly * night150Hours * settings.NormalOvertimeRate;
        decimal night215Pay = hourly * night215Hours * settings.NightOvertimeAfter2Rate;
        decimal totalOt = s.DayOtPay + s.SundayDayPay + s.NightExtraPay + s.NightOtPay + s.SundayNightPay;

        string pct(decimal rate) => (rate * 100m).ToString("0.##", CultureInfo.InvariantCulture).Replace('.', ',') + "%";

        var values = new object?[,]
        {
            { $"Lương Tháng {month:00}/{year}", null, null, null },
            { $"Họ Và Tên: {emp.Name}", null, $"Số Thẻ: {emp.Code}", null },
            { "ngày công tiêu chuẩn", standardDays, $"số giờ tăng ca ngày thường {pct(settings.NormalOvertimeRate)}", normalDayHours },
            { "ngày công thực tế", s.PaidDays, "số tiền tăng ca ngày thường", s.DayOtPay },
            { "tổng lương tháng", salaryBase, $"số giờ tăng ca Chủ nhật {pct(settings.SundayDayRate)}", sundayDayHours },
            { "lương tính tăng ca", otBase, "số tiền tăng ca Chủ nhật", s.SundayDayPay },
            { "số tiền tăng ca mỗi giờ", hourly, $"số giờ tăng ca đêm cộng thêm {pct(settings.NightExtraRate)}", nightExtraHours },
            { "tiền chuyên cần", s.AttendanceBonus, $"số tiền tăng ca đêm cộng thêm {pct(settings.NightExtraRate)}", s.NightExtraPay },
            { "lương theo ngày công", s.BasePay, $"số giờ tăng ca đêm thường {pct(settings.NormalOvertimeRate)}", night150Hours },
            { "", "", $"số tiền tăng ca đêm thường {pct(settings.NormalOvertimeRate)}", night150Pay },
            { "", "", $"số giờ tăng ca đêm thường {pct(settings.NightOvertimeAfter2Rate)}", night215Hours },
            { "", "", $"số tiền tăng ca đêm thường {pct(settings.NightOvertimeAfter2Rate)}", night215Pay },
            { "", "", $"số giờ tăng ca đêm Chủ nhật {pct(settings.SundayNightRate)}", sundayNightHours },
            { "", "", "số tiền tăng ca đêm Chủ nhật", s.SundayNightPay },
            { "", "", "Tổng Tiền Tăng Ca", totalOt },
            { "", "", "", "" },
            { "", "", $"BẢO HIỂM {pct(settings.InsuranceRate)}", s.Insurance },
            { "", "", $"công đoàn phí {pct(settings.UnionRate)}", s.UnionFee },
            { "", "", "", "" },
            { "", "", "", "" },
            { "", "", "Tổng Lương", s.Gross },
            { "", "", "Thực Lĩnh", s.Net }
        };

        var sb = new StringBuilder();
        sb.Append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
        sb.Append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
        sb.Append("<sheetPr><pageSetUpPr fitToPage=\"1\"/></sheetPr>");
        sb.Append("<dimension ref=\"A1:D22\"/>");
        sb.Append("<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"2\" topLeftCell=\"A3\" activePane=\"bottomLeft\" state=\"frozen\"/><selection pane=\"bottomLeft\"/></sheetView></sheetViews>");
        sb.Append("<sheetFormatPr defaultRowHeight=\"15\"/>");
        sb.Append("<cols><col min=\"1\" max=\"1\" width=\"32\" customWidth=\"1\"/><col min=\"2\" max=\"2\" width=\"17\" customWidth=\"1\"/><col min=\"3\" max=\"3\" width=\"38\" customWidth=\"1\"/><col min=\"4\" max=\"4\" width=\"18\" customWidth=\"1\"/></cols>");
        sb.Append("<sheetData>");

        for (int r = 0; r < 22; r++)
        {
            int row = r + 1;
            int height = row == 1 ? 26 : row == 2 ? 28 : 24;
            sb.Append($"<row r=\"{row}\" ht=\"{height}\" customHeight=\"1\">");
            for (int c = 0; c < 4; c++)
            {
                int style = StyleAt(row, c + 1, values[r, c]);
                AppendCell(sb, CellRef(c + 1, row), values[r, c], style);
            }
            sb.Append("</row>");
        }

        sb.Append("</sheetData>");
        sb.Append("<mergeCells count=\"3\"><mergeCell ref=\"A1:D1\"/><mergeCell ref=\"A2:B2\"/><mergeCell ref=\"C2:D2\"/></mergeCells>");
        sb.Append("<pageMargins left=\"0.25\" right=\"0.25\" top=\"0.35\" bottom=\"0.35\" header=\"0.2\" footer=\"0.2\"/>");
        sb.Append("<pageSetup paperSize=\"9\" orientation=\"portrait\" scale=\"100\" fitToWidth=\"1\" fitToHeight=\"1\"/>");
        sb.Append("</worksheet>");
        return sb.ToString();
    }

    static int StyleAt(int row, int col, object? value)
    {
        if (row == 1) return 1;
        if (row == 2) return 2;
        if (row == 17 || row == 18)
        {
            if (col == 3) return 10;
            if (col == 4) return 11;
        }
        if (row == 21)
        {
            if (col == 3) return 12;
            if (col == 4) return 13;
        }
        if (row == 22)
        {
            if (col == 3) return 14;
            if (col == 4) return 15;
        }
        if (row == 15 && col == 3) return 9;
        if (col == 1 || col == 3) return 3;
        if (value is string) return 8;
        if (col == 2)
        {
            if (row == 7) return 7;
            if (row == 3 || row == 4) return 4;
            return 6;
        }
        if (col == 4)
        {
            if (row == 3 || row == 5 || row == 7 || row == 9 || row == 11 || row == 13) return 5;
            return 6;
        }
        return 0;
    }

    static void AppendCell(StringBuilder sb, string cell, object? value, int style)
    {
        if (value is decimal dec)
        {
            sb.Append($"<c r=\"{cell}\" s=\"{style}\"><v>{dec.ToString(CultureInfo.InvariantCulture)}</v></c>");
        }
        else if (value is int iv)
        {
            sb.Append($"<c r=\"{cell}\" s=\"{style}\"><v>{iv}</v></c>");
        }
        else
        {
            string text = Escape(value?.ToString() ?? "");
            sb.Append($"<c r=\"{cell}\" s=\"{style}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">{text}</t></is></c>");
        }
    }

    static string CellRef(int col, int row)
    {
        var s = "";
        while (col > 0) { col--; s = (char)('A' + col % 26) + s; col /= 26; }
        return s + row;
    }

    static string SheetName(Employee emp, int index, HashSet<string> used)
    {
        string raw = string.IsNullOrWhiteSpace(emp.Code) ? emp.Name : emp.Code + " - " + emp.Name;
        foreach (char ch in new[] { ':', '\\', '/', '?', '*', '[', ']' }) raw = raw.Replace(ch, '-');
        raw = raw.Trim().Trim('\'');
        if (string.IsNullOrWhiteSpace(raw)) raw = $"Nhân viên {index + 1}";
        if (raw.Length > 31) raw = raw[..31];
        string name = raw;
        int n = 2;
        while (!used.Add(name))
        {
            string suffix = $" ({n++})";
            int max = 31 - suffix.Length;
            name = (raw.Length > max ? raw[..max] : raw) + suffix;
        }
        return name;
    }

    static string Escape(string s) => SecurityElement.Escape(s) ?? "";

    static void Write(ZipArchive zip, string path, string text)
    {
        var e = zip.CreateEntry(path, CompressionLevel.Optimal);
        using var w = new StreamWriter(e.Open(), new UTF8Encoding(false));
        w.Write(text);
    }

    static string ContentTypes(int count)
    {
        var sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
        for (int i = 1; i <= count; i++) sb.Append($"<Override PartName=\"/xl/worksheets/sheet{i}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
        sb.Append("</Types>");
        return sb.ToString();
    }

    static string RootRels() => """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""";

    static string WorkbookXml(List<Employee> employees)
    {
        var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>");
        for (int i = 0; i < employees.Count; i++)
        {
            string name = Escape(SheetName(employees[i], i, used));
            sb.Append($"<sheet name=\"{name}\" sheetId=\"{i + 1}\" r:id=\"rId{i + 1}\"/>");
        }
        sb.Append("</sheets></workbook>");
        return sb.ToString();
    }

    static string WorkbookRels(int count)
    {
        var sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
        for (int i = 1; i <= count; i++) sb.Append($"<Relationship Id=\"rId{i}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet{i}.xml\"/>");
        sb.Append($"<Relationship Id=\"rId{count + 1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>");
        return sb.ToString();
    }

    static string StylesXml() =>
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
        "<numFmts count=\"1\"><numFmt numFmtId=\"164\" formatCode=\"0.##\"/></numFmts>" +
        "<fonts count=\"5\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"15\"/><name val=\"Arial\"/></font><font><b/><sz val=\"11\"/><name val=\"Arial\"/></font><font><sz val=\"11\"/><name val=\"Arial\"/></font><font><b/><sz val=\"12\"/><name val=\"Arial\"/></font></fonts>" +
        "<fills count=\"5\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFFFF2F2\"/></patternFill></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFEAF2F8\"/></patternFill></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFD9EAD3\"/></patternFill></fill></fills>" +
        "<borders count=\"2\"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style=\"thin\"><color rgb=\"FF000000\"/></left><right style=\"thin\"><color rgb=\"FF000000\"/></right><top style=\"thin\"><color rgb=\"FF000000\"/></top><bottom style=\"thin\"><color rgb=\"FF000000\"/></bottom><diagonal/></border></borders>" +
        "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
        "<cellXfs count=\"16\">" +
        "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +
        "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\" vertical=\"center\"/></xf>" +
        "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\" vertical=\"center\"/></xf>" +
        "<xf numFmtId=\"0\" fontId=\"3\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"left\" vertical=\"center\" wrapText=\"1\"/></xf>" +
        "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"right\" vertical=\"center\"/></xf>" +
        "<xf numFmtId=\"164\" fontId=\"2\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyNumberFormat=\"1\" applyFont=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"right\" vertical=\"center\"/></xf>" +
        "<xf numFmtId=\"3\" fontId=\"2\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyNumberFormat=\"1\" applyFont=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"right\" vertical=\"center\"/></xf>" +
        "<xf numFmtId=\"4\" fontId=\"3\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyNumberFormat=\"1\" applyFont=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"right\" vertical=\"center\"/></xf>" +
        "<xf numFmtId=\"0\" fontId=\"3\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"right\" vertical=\"center\"/></xf>" +
        "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"left\" vertical=\"center\" wrapText=\"1\"/></xf>" +
        "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"2\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"left\" vertical=\"center\" wrapText=\"1\"/></xf>" +
        "<xf numFmtId=\"3\" fontId=\"2\" fillId=\"2\" borderId=\"1\" xfId=\"0\" applyNumberFormat=\"1\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"right\" vertical=\"center\"/></xf>" +
        "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"3\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"left\" vertical=\"center\" wrapText=\"1\"/></xf>" +
        "<xf numFmtId=\"3\" fontId=\"2\" fillId=\"3\" borderId=\"1\" xfId=\"0\" applyNumberFormat=\"1\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"right\" vertical=\"center\"/></xf>" +
        "<xf numFmtId=\"0\" fontId=\"4\" fillId=\"4\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"left\" vertical=\"center\" wrapText=\"1\"/></xf>" +
        "<xf numFmtId=\"3\" fontId=\"4\" fillId=\"4\" borderId=\"1\" xfId=\"0\" applyNumberFormat=\"1\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"right\" vertical=\"center\"/></xf>" +
        "</cellXfs><cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles><dxfs count=\"0\"/><tableStyles count=\"0\" defaultTableStyle=\"TableStyleMedium2\" defaultPivotStyle=\"PivotStyleLight16\"/></styleSheet>";
}
