ChamCongTinhLuongNative v5.0.7 - WPF

Moi o v5.0.7:
- Menu Cai dat co Quy tac luong: cong chuan, thuong chuyen can, BH, cong doan, OT ngay thuong, CN ngay/dem, phu cap ca dem, OT dem sau 2h, gio CN mac dinh.
- Cai dat Phep nam: ngay tu cong va so phep cong moi thang.
- Sao luu/Khoi phuc du lieu JSON.
- Cac gia tri mac dinh giu dung quy tac cu neu data.json chua co Settings.

Du lieu: %LOCALAPPDATA%\ChamCongTinhLuong\data.json
Build: chay build.bat

Moi o v5.0.7:
- Tach chi tiet Luong thuc nhan: Luong cong, OT ngay, OT dem, Ca dem, Chu nhat, Chuyen can, Bao hiem, Cong doan.
- Tong luong khong doi, chi tach rieng OT dem de hien thi chinh xac.
